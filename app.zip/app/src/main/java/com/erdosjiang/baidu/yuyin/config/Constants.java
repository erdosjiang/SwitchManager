package com.erdosjiang.baidu.yuyin.config;

public class Constants {
    //语音识别结束状态
    public static final int STATUS_RECOG_SUCCESS_RESULT = 69001;
    //智能主机操作类别_无线按钮
    public static final int SMART_TYPE_WIRELESS = 69101;
}
